<?php

<?DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="style/style1.css" />
<script language="javascript" src="script/script.js"></script>
</head>

<body>

<div class="topav">
<a href="index.html">trang chu</a>
<a href="page1.html">san pham moi</a>
<a href="page2.html">san pham thong dung</a>
<a href="page3.html">ve chung toi</a>
</div>
<img src="image/1.jpg" height="500px" width="1285px" />

</body>
</html>
?>